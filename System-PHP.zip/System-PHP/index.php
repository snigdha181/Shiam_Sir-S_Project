<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Student Grading PHP</title>
  <meta content="" name="descriptison">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link rel="shortcut icon" href="assets/img/ronk1.jpg" />
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet"> -->
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style22.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Mentor - v2.0.0
  * Template URL: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">
      <a class="navbar-brand" href="index.php"><img src="assets/img/student-grade.png" alt="Logo" style="width:30px;height:30px;"></a>
      <h1 class="logo mr-auto"><a href="index.php">Result Management System</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo mr-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li class="active"><a href="#hero">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#courses">Courses</a></li>
          <li><a href="#footer">Contact</a></li>

          <li class="drop-down"><a href="">Login </a> 
            <ul>
              <li><a href="adminLogin.php">Admin</a></li>
              <li><a href="studentLogin.php">Student</a></li>
			  <!-- Log on to codeastro.com for more projects! -->
             
            </ul>
          </li>

        </ul>
      </nav><!-- .nav-menu -->

      <!-- <a href="#" class="get-started-btn">Alumni</a> -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex justify-content-center align-items-center" style="background-image: url('assets/img/bg2.jpg');">
    <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100">
      
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <p>Our Mission</p>
        </div>

        <div class="row">
          <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
            <img src="assets/img/mission.jpg" style="height:400px;" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <p>
            Through our results management system, we aim to revolutionize the way Sheikh Hasina University manages academic results, making the process seamless, accurate and effortlessly efficient. We are driven by a commitment to increasing transparency, so that students can get secure, error-free results with ease and confidence. By simplifying administrative tasks like calculating and saving results, we free up valuable time for teachers to motivate and guide their students towards success. Embracing the power of digital transformation, our system replaces outdated, manual processes with a modern, intelligent solution designed to keep pace with today’s rapidly evolving educational needs. Above all, we provide students with instant insights into their achievements and performance, inspiring them to excel and make informed decisions for a brighter future. Through this system, we aim to bridge the gap between technology and education, shaping a future where innovation and academic excellence go hand in hand.

            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->
    
    

    
    
     <!-- ======= Courses Section ======= -->
<section id="courses" class="courses">
  <div class="container" data-aos="fade-up">
    <div class="section-title">
      <p>Explore the Courses Offered for Each Year</p>
    </div>

    <div class="row">
      <!-- First Year -->
      <div class="col-lg-3 col-md-6">
        <div class="course-list">
          <h4>First Year Courses</h4>
          <ul>
            <li><a href="#">Fundamentals of Computers and Computing </a></li>
            <li><a href="#">Discrete Mathematics  </a></li>
            <li><a href="#">Electrical Circuits  </a></li>
            <li><a href="#">Physics </a></li>
            <li><a href="#">Differential and Integral Calculus </a></li>
            <li><a href="#">Fundamentals of Programming </a></li>
            <li><a href="#">Digital Logic Design</a></li>
            <li><a href="#">Chemistry</a></li>
            <li><a href="#">Method of Integration, Differential Equations, and Series</a></li>
          </ul>
        </div>
      </div>

      <!-- Second Year -->
      <div class="col-lg-3 col-md-6">
        <div class="course-list">
          <h4>Second Year Courses</h4>
          <ul>
            <li><a href="#">Data Structures and Algorithms</a></li>
            <li><a href="#">Object Oriented Programming</a></li>
            <li><a href="#">Electronic Devices and Circuits</a></li>
            <li><a href="#">Bangladesh Studies</a></li>
            <li><a href="#">Linear Algebra</a></li>
            <li><a href="#">Database Management Systems</a></li>
            <li><a href="#">Design and Analysis of Algorithms</a></li>
            <li><a href="#">Data and Telecommunication </a></li>
            <li><a href="#">Computer Architecture and Organization </a></li>
            <li><a href="#">Introduction to Mechatronics </a></li>
          </ul>
        </div>
      </div>

      <!-- Third Year -->
      <div class="col-lg-3 col-md-6">
        <div class="course-list">
          <h4>Third Year Courses</h4>
          <ul>
            <li><a href="#">Computer Networking </a></li>
            <li><a href="#">Software Engineering  </a></li>
            <li><a href="#">Microprocessor and Microcontroller  </a></li>
            <li><a href="#">Formal Language, Automata and Computability </a></li>
            <li><a href="#">Multivariable Calculus and Geometry  </a></li>
            <li><a href="#">Operating Systems  </a></li>
            <li><a href="#">Numerical Methods </a></li>
            <li><a href="#">Digital Image Processing  </a></li>
            <li><a href="#">Compiler Design  </a></li>
            <li><a href="#">Introduction to Probability and Statistics </a></li>
          </ul>
        </div>
      </div>

      <!-- Fourth Year -->
      <div class="col-lg-3 col-md-6">
        <div class="course-list">
          <h4>Fourth Year Courses</h4>
          <ul>
            <li><a href="#">Artificial Intelligence </a></li>
            <li><a href="#">Mathematical and Statistical Analysis for Engineers</a></li>
            <li><a href="#">Graph Theory</a></li>
            <li><a href="#">Economics</a></li>
            <li><a href="#">Society and Technology</a></li>
            <li><a href="#">Cryptography and Security</a></li>
            <li><a href="#">Introduction to Machine Learning </a></li>
            <li><a href="#">Introduction to Data mining and warehousing </a></li>
            <li><a href="#">Computer Vision</a></li>
            <li><a href="#">Computer and Network Security</a></li>
          </ul>
        </div>
      </div>
    </div>

  </div>
</section><!-- End Courses Section -->


  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Sheikh Hasina University, Netrakona</h3>
            <p>
            Rajur Bazar, <br>
            Mymensingh - Sunamganj Rd<br><br>
              <strong>Phone:</strong> +8802997735008<br>
              <strong>Email:</strong>  info@shu.edu.bd<br>
              <strong>Website:</strong>  www.shu.edu.bd<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Important Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://bangladesh.gov.bd/index.php" target="_blank">Bangladesh National Portal</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://bangabhaban.gov.bd/index.php" target="_blank">Office of the President</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://pmo.gov.bd/" target="_blank">Prime Minister's Office</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://www.moedu.gov.bd/" target="_blank">Ministry of Education</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Departments</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="https://www.shu.edu.bd/department-of-bangla/" target="_blank">Bangla</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://www.shu.edu.bd/department-of-english/" target="_blank">English</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://www.shu.edu.bd/department-of-economics/" target="_blank">Economics</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://www.shu.edu.bd/department-of-computer-science-engineering/" target="_blank">Computer Science and Engineering</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Newsletter</h4>
            <p>Some random text spaces here. For now, just a demo text all over!</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe Now!!">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="mr-md-auto text-center text-md-left">
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/mentor-free-education-bootstrap-theme/ -->
          <!-- Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> -->
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/shubdofficial?ref=embed_page" target="_blank" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top"><i class="bx bx-up-arrow-alt"></i></a>
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>