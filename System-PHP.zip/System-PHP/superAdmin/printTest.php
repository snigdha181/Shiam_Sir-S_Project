<?php
// Namespace and required dependencies
namespace Dompdf;
require_once 'dompdf/autoload.inc.php';

// Start buffering output
ob_start();

// Suppress error reporting (not recommended for production)
error_reporting(0);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Grading System</title>
    <style>
        body {
            padding: 4px;
            text-align: center;
        }

        table {
            width: 100%;
            margin: 10px auto;
            border-collapse: collapse;
            text-align: center;
        }

        th, td {
            padding: 8px;
            border: 1px solid black;
        }

        h2, h4 {
            margin: 0;
            padding: 8px;
        }

        p {
            margin: 5px;
            text-align: left;
        }
    </style>
</head>
<body>
    <h2><b>STUDENT GRADING SYSTEM - PHP</b></h2>
    <h4><b>COMPUTER SCIENCE DEPARTMENT</b></h4>

    <?php 
    // Replace deprecated mysql functions with mysqli or PDO
    $connection = mysqli_connect("localhost", "username", "password", "database_name");

    if (!$connection) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    session_start();

    $matricno = $_SESSION['alogin'];
    $query = "SELECT * FROM students WHERE matricno='$matricno'";
    $result = mysqli_query($connection, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    ?>
    <div align="left">
        <p><b>Student Name:</b> <?php echo $row['surname'] . ' ' . $row['firstname'] . ' ' . $row['othername']; ?></p>
        <p><b>Year:</b> <?php echo $row['level']; ?></p>
        <p><b>Session:</b> <?php echo $row['session']; ?></p>
        <p><b>Reg No:</b> <?php echo $row['matricno']; ?></p>
        <p><b>Sex:</b> <?php echo $row['sex']; ?></p>
    </div>

    <h4><b>CLEARANCE FOR <?php echo $row['session'] . ' SESSION ' . $row['level'] . ' LEVEL'; ?></b></h4>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Requirement</th>
                <th>Reg No</th>
                <th>Session</th>
                <th>Year</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sn = 0;
            $req_query = "SELECT * FROM requploads WHERE matricno='$matricno' AND session='{$row['session']}' AND level='{$row['level']}'";
            $req_result = mysqli_query($connection, $req_query);

            while ($req_row = mysqli_fetch_assoc($req_result)) {
                $reqId = $req_row['reqId'];
                $details_query = "SELECT * FROM requirements WHERE reqid='$reqId'";
                $details_result = mysqli_query($connection, $details_query);

                while ($details_row = mysqli_fetch_assoc($details_result)) {
                    $sn++;
            ?>
            <tr>
                <td><?php echo $sn; ?></td>
                <td><?php echo $details_row['reqName']; ?></td>
                <td><?php echo $req_row['matricno']; ?></td>
                <td><?php echo $req_row['session']; ?></td>
                <td><?php echo $req_row['level']; ?></td>
                <td><?php echo $req_row['uploadStatus']; ?></td>
            </tr>
            <?php
                }
            }
            ?>
        </tbody>
    </table>
    <?php
    } else {
        echo "<p>No data found for the student.</p>";
    }

    mysqli_close($connection);
    ?>
</body>
</html>

<?php
$html = ob_get_clean();
$dompdf = new Dompdf();
$dompdf->setPaper('A4', 'landscape');
$dompdf->loadHtml($html);
$dompdf->render();
$dompdf->stream("Clearance.pdf", ["Attachment" => false]);
?>
