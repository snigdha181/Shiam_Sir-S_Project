<?php
use Dompdf\Dompdf;
require_once '../dompdf/autoload.inc.php';

ob_start();
include('../includes/dbconnection.php');
include('../includes/session.php');
include('../includes/functions.php');

if (isset($_GET['matricNo'], $_GET['levelId'], $_GET['sessionId'], $_GET['semesterId'])) {
    $matricNo = $_GET['matricNo'];
    $levelId = $_GET['levelId'];
    $sessionId = $_GET['sessionId'];
    $semesterId = $_GET['semesterId'];

    $stdQuery = mysqli_query($con, "SELECT * FROM tblstudent WHERE matricNo = '$matricNo'");
    $rowStd = mysqli_fetch_array($stdQuery);
    $departmentId = $rowStd['departmentId'] ?? null;

    $semesterQuery = mysqli_query($con, "SELECT * FROM tblsemester WHERE Id = '$semesterId'");
    $rowSemester = mysqli_fetch_array($semesterQuery);

    $sessionQuery = mysqli_query($con, "SELECT * FROM tblsession WHERE Id = '$sessionId'");
    $rowSession = mysqli_fetch_array($sessionQuery);

    $levelQuery = mysqli_query($con, "SELECT * FROM tbllevel WHERE Id = '$levelId'");
    $rowLevel = mysqli_fetch_array($levelQuery);

    $deptQuery = mysqli_query($con, "SELECT * FROM tbldepartment WHERE Id = '$departmentId'");
    $rowDept = mysqli_fetch_array($deptQuery);
} else {
    echo "<script type='text/javascript'>
    window.location = ('studentList3.php');
    </script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Semester Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .header h3 {
            margin: 5px 0;
        }
        .details {
            margin: 10px 0;
            font-size: 14px;
        }
        .details h4 {
            margin: 5px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 10px 0;
            font-size: 14px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h3>Sheikh Hasina University</h3>
        <h4><?php echo $rowDept['departmentName'] ?? 'Department'; ?> Department</h4>
    </div>

    <div class="details">
        <h4>Student: <b><?php echo $rowStd['firstName'] . ' ' . $rowStd['lastName'] . ' ' . ($rowStd['otherName'] ?? ''); ?></b></h4>
        <h4>Reg No: <b><?php echo $rowStd['matricNo']; ?></b></h4>
        <h4>Semester: <b><?php echo $rowSemester['semesterName'] ?? ''; ?></b></h4>
        <h4>Year: <b><?php echo $rowLevel['levelName'] ?? ''; ?></b></h4>
        <h4>Session: <b><?php echo $rowSession['sessionName'] ?? ''; ?></b></h4>
    </div>

    <h4 align="center">Result Details</h4>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Course Title</th>
                <th>Course Code</th>
                <th>Course Credit</th>
                <th>Score</th>
                <th>Grade</th>
                <th>Grade Point</th>
                <th>Total Grade Point</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $ret = mysqli_query($con, "SELECT tblresult.courseCode, tblresult.courseUnit, tblresult.score, tblresult.scoreGradePoint, tblresult.scoreLetterGrade, tblresult.totalScoreGradePoint, tblcourse.courseTitle FROM tblresult INNER JOIN tblcourse ON tblcourse.courseCode = tblresult.courseCode WHERE tblresult.levelId = '$levelId' AND tblresult.sessionId = '$sessionId' AND tblresult.semesterId = '$semesterId' AND tblresult.matricNo = '$matricNo'");
            $cnt = 1;
            $totalCourseUnit = 0;
            $totalScoreGradePoint = 0;
            while ($row = mysqli_fetch_array($ret)) {
                echo "<tr>
                        <td>{$cnt}</td>
                        <td>{$row['courseTitle']}</td>
                        <td>{$row['courseCode']}</td>
                        <td>{$row['courseUnit']}</td>
                        <td>{$row['score']}</td>
                        <td>{$row['scoreLetterGrade']}</td>
                        <td>{$row['scoreGradePoint']}</td>
                        <td>{$row['totalScoreGradePoint']}</td>
                    </tr>";
                $cnt++;
                $totalCourseUnit += $row['courseUnit'];
                $totalScoreGradePoint += $row['totalScoreGradePoint'];
            }
            ?>
            <tr>
                <td colspan="3">Total</td>
                <td><?php echo $totalCourseUnit; ?></td>
                <td colspan="3"></td>
                <td><?php echo $totalScoreGradePoint; ?></td>
            </tr>
        </tbody>
    </table>

    <h4 align="center">Final Result</h4>
    <table>
        <thead>
            <tr>
                <th>Total Course Unit</th>
                <th>Total Grade Point</th>
                <th>GPA</th>
                <th>Class of Diploma</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $ret = mysqli_query($con, "SELECT * FROM tblfinalresult WHERE matricNo = '$matricNo' AND levelId = '$levelId' AND sessionId = '$sessionId' AND semesterId = '$semesterId'");
            while ($row = mysqli_fetch_array($ret)) {
                echo "<tr>
                        <td>{$row['totalCourseUnit']}</td>
                        <td>{$row['totalScoreGradePoint']}</td>
                        <td>{$row['gpa']}</td>
                        <td>{$row['classOfDiploma']}</td>
                    </tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="footer">
        <p>HOD's Signature | Registrar's Signature</p>
        <p>Date: <?php echo date('Y-m-d'); ?></p>
    </div>
</body>
</html>
<?php
$html = ob_get_clean();
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream('document.pdf', ['Attachment' => false]);
?>
